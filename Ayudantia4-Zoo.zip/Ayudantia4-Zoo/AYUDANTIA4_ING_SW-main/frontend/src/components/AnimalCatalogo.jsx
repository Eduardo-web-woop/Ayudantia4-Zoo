import { useEffect, useState } from 'react';
import { API_URL } from '../api/config';

const obtenerMensajeError = (data) => {
  if (data?.detalles?.length) {
    return data.detalles.map((detalle) => detalle.mensaje).join(' ');
  }

  return data?.error || 'No se pudo completar la solicitud';
};

function AnimalCatalogo() {
  const [animales, setAnimales] = useState([]);
  const [especies, setEspecies] = useState([]);
  const [recintos, setRecintos] = useState([]);
  const [animalSeleccionado, setAnimalSeleccionado] = useState(null);
  const [comentarios, setComentarios] = useState([]);
  const [promedio, setPromedio] = useState(null);
  const [especieId, setEspecieId] = useState('');
  const [recintoId, setRecintoId] = useState('');
  const [cargando, setCargando] = useState(true);
  const [cargandoComentarios, setCargandoComentarios] = useState(false);
  const [error, setError] = useState(null);
  const [errorComentario, setErrorComentario] = useState(null);
  const [enviandoComentario, setEnviandoComentario] = useState(false);
  const [formulario, setFormulario] = useState({
    autor: '',
    calificacion: '5',
    comentario: '',
  });

  useEffect(() => {
    Promise.all([fetch(`${API_URL}/especies`), fetch(`${API_URL}/recintos`)])
      .then(async ([respuestaEspecies, respuestaRecintos]) => {
        if (!respuestaEspecies.ok || !respuestaRecintos.ok) {
          throw new Error('No se pudieron cargar los filtros');
        }

        const [datosEspecies, datosRecintos] = await Promise.all([
          respuestaEspecies.json(),
          respuestaRecintos.json(),
        ]);
        setEspecies(datosEspecies);
        setRecintos(datosRecintos);
      })
      .catch(() => setError('No se pudieron cargar las especies y los recintos.'));
  }, []);

  useEffect(() => {
    const params = new URLSearchParams();
    if (especieId) params.set('especieId', especieId);
    if (recintoId) params.set('recintoId', recintoId);

    fetch(`${API_URL}/animals${params.toString() ? `?${params}` : ''}`)
      .then(async (respuesta) => {
        const datos = await respuesta.json();
        if (!respuesta.ok) throw new Error(obtenerMensajeError(datos));
        setAnimales(datos);
        setCargando(false);
      })
      .catch((err) => {
        setError(err.message || 'No se pudo conectar con el servidor.');
        setCargando(false);
      });
  }, [especieId, recintoId]);

  const seleccionarAnimal = async (animal) => {
    setAnimalSeleccionado(animal);
    setComentarios([]);
    setPromedio(null);
    setErrorComentario(null);
    setCargandoComentarios(true);

    try {
      const respuesta = await fetch(`${API_URL}/animals/${animal.id}/comments`);
      const datos = await respuesta.json();
      if (!respuesta.ok) throw new Error(obtenerMensajeError(datos));

      setComentarios(datos.comentarios);
      setPromedio(datos.averageRating);
    } catch (err) {
      setErrorComentario(err.message || 'No se pudieron cargar los comentarios.');
    } finally {
      setCargandoComentarios(false);
    }
  };

  const enviarComentario = async (evento) => {
    evento.preventDefault();
    if (!animalSeleccionado) return;

    setEnviandoComentario(true);
    setErrorComentario(null);

    try {
      const respuesta = await fetch(`${API_URL}/animals/${animalSeleccionado.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formulario,
          calificacion: Number(formulario.calificacion),
        }),
      });
      const datos = await respuesta.json();

      if (!respuesta.ok) throw new Error(obtenerMensajeError(datos));

      setFormulario({ autor: '', calificacion: '5', comentario: '' });
      await seleccionarAnimal(animalSeleccionado);
    } catch (err) {
      setErrorComentario(err.message || 'No se pudo crear el comentario.');
    } finally {
      setEnviandoComentario(false);
    }
  };

  const cambiarCampo = (evento) => {
    const { name, value } = evento.target;
    setFormulario((anterior) => ({ ...anterior, [name]: value }));
  };

  const cambiarFiltro = (actualizarFiltro) => (evento) => {
    setCargando(true);
    setError(null);
    actualizarFiltro(evento.target.value);
  };

  return (
    <section style={{ marginTop: '2rem' }}>
      <h2>Catálogo de animales</h2>

      <div>
        <label>
          Especie{' '}
          <select value={especieId} onChange={cambiarFiltro(setEspecieId)}>
            <option value="">Todas las especies</option>
            {especies.map((especie) => (
              <option key={especie.id} value={especie.id}>{especie.nombre}</option>
            ))}
          </select>
        </label>{' '}
        <label>
          Recinto{' '}
          <select value={recintoId} onChange={cambiarFiltro(setRecintoId)}>
            <option value="">Todos los recintos</option>
            {recintos.map((recinto) => (
              <option key={recinto.id} value={recinto.id}>{recinto.nombre}</option>
            ))}
          </select>
        </label>
      </div>

      {cargando && <p>Cargando animales...</p>}
      {error && <p role="alert">{error}</p>}
      {!cargando && !error && (
        <ul>
          {animales.map((animal) => (
            <li key={animal.id}>
              <button type="button" onClick={() => seleccionarAnimal(animal)}>
                {animal.nombre}
              </button>{' '}
              — {animal.especie.nombre}, {animal.recinto.nombre}
            </li>
          ))}
        </ul>
      )}
      {!cargando && !error && animales.length === 0 && <p>No hay animales con estos filtros.</p>}

      {animalSeleccionado && (
        <article style={{ marginTop: '1.5rem' }}>
          <h3>{animalSeleccionado.nombre}</h3>
          <p>
            {animalSeleccionado.edad} año(s) · {animalSeleccionado.peso ?? 'Sin dato'} kg ·{' '}
            {animalSeleccionado.disponible ? 'Disponible' : 'No disponible'}
          </p>
          <p>Especie: {animalSeleccionado.especie.nombre} · Recinto: {animalSeleccionado.recinto.nombre}</p>

          <h4>Comentarios</h4>
          {cargandoComentarios && <p>Cargando comentarios...</p>}
          {errorComentario && <p role="alert">{errorComentario}</p>}
          {!cargandoComentarios && !errorComentario && (
            <>
              <p>Calificación promedio: {promedio === null ? 'Sin calificaciones' : promedio.toFixed(1)}</p>
              {comentarios.length ? (
                <ul>
                  {comentarios.map((comentario) => (
                    <li key={comentario.id}>
                      <strong>{comentario.autor}</strong> — {comentario.calificacion}/5: {comentario.comentario}
                    </li>
                  ))}
                </ul>
              ) : <p>Aún no hay comentarios.</p>}
            </>
          )}

          <h4>Agregar comentario</h4>
          <form onSubmit={enviarComentario}>
            <p>
              <label>
                Autor{' '}
                <input name="autor" value={formulario.autor} onChange={cambiarCampo} required />
              </label>
            </p>
            <p>
              <label>
                Calificación{' '}
                <select name="calificacion" value={formulario.calificacion} onChange={cambiarCampo}>
                  {[1, 2, 3, 4, 5].map((valor) => <option key={valor} value={valor}>{valor}</option>)}
                </select>
              </label>
            </p>
            <p>
              <label>
                Comentario{' '}
                <textarea name="comentario" value={formulario.comentario} onChange={cambiarCampo} required />
              </label>
            </p>
            <button type="submit" disabled={enviandoComentario}>
              {enviandoComentario ? 'Enviando...' : 'Publicar comentario'}
            </button>
          </form>
        </article>
      )}
    </section>
  );
}

export default AnimalCatalogo;